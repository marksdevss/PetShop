import petshop.ClientePet;
import entidades.Cliente;

public class Main {
    public static void main(String[] args) {
        ClientePet clientePet = new ClientePet();
        Cliente cliente = new Cliente();

        cliente.setnome("Lucas");
        cliente.setCpf("3874834");
        cliente.setEndereco("Paris");
        cliente.setTelefone("2343525");

        //Criando Cliente

        clientePet.CreateCliente(cliente);

        //Mostrando Cliente

        for (Cliente showCliente : clientePet.ShowClientes()) {
            System.out.println("Nome do cliente: " +showCliente.getNome());
            System.out.println("Cpf do cliente: " +showCliente.getCpf());
            System.out.println("Endereco do cliente: " +showCliente.getEndereco());
            System.out.println("Telefone do cliente: " +showCliente.getTelefone());
            System.out.println("======================================");
        }


    }
}