import entidades.Animal;

import petshop.AnimalPet;

public class Main2 {

    public static void main(String[] args) {

        AnimalPet animalPet = new AnimalPet();
        Animal animal = new Animal();

        animal.setNome("Juca");
        animal.setRaca("salsicha");
        animal.setEspecie("cachorro");
        animal.setIdade(23);
        animal.setGenero("Macho");

        //Criando Animal

        //animalPet.CreateAnimal(animal);


        //Mostrando Animal

        // for (Animal ShowAnimal : animalPet.ShowAnimal()) {
        //System.out.println("Nome do Animal: " + ShowAnimal.getNome());
        //System.out.println("Raca do Animal: " + ShowAnimal.getRaca());
        //System.out.println("Especie do Animal: " + ShowAnimal.getEspecie());
        //System.out.println("Idade do Animal: " + ShowAnimal.getIdade());
        //System.out.println("Genero do Animal: " + ShowAnimal.getGenero());
       // System.out.println("======================================");
        //}

        //Atualizando Animal

        animalPet.UpdateAnimal(animal);

        for(Animal UpdateAnimal  : animalPet.UpdateAnimal()){
        System.out.println("Nome do Animal: " +UpdateAnimal.getNome());
        System.out.println("Raca do Animal: " + UpdateAnimal.getRaca());
        System.out.println("Especie do Animal: " + UpdateAnimal.getEspecie());
        System.out.println("Idade do Animal: " + UpdateAnimal.getIdade());
        System.out.println("Genero do Animal: " + UpdateAnimal.getGenero());
         System.out.println("======================================");
        }

        }

    //Deletando Animal

    


}